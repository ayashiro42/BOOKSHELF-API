const { nanoid } = require("nanoid");
const books = require("./books");

// ✅ Menyimpan buku baru
const addBookHandler = (request, h) => {
  const { title, author, year, summary } = request.payload;
  const id = nanoid(16);

  if (!title) {
    return h.response({ status: "fail", message: "Title is required" }).code(400);
  }

  const newBook = { id, title, author, year, summary };
  books.push(newBook);

  return h.response({ status: "success", message: "Book added", data: { bookId: id } }).code(201);
};

// ✅ Menampilkan seluruh buku
const getAllBooksHandler = () => ({
  status: "success",
  data: { books },
});

// ✅ Menampilkan detail buku berdasarkan ID
const getBookByIdHandler = (request, h) => {
  const { id } = request.params;
  const book = books.find((b) => b.id === id);

  if (!book) {
    return h.response({ status: "fail", message: "Book not found" }).code(404);
  }

  return h.response({ status: "success", data: { book } });
};

// ✅ Mengubah data buku
const updateBookHandler = (request, h) => {
  const { id } = request.params;
  const { title, author, year, summary } = request.payload;
  const index = books.findIndex((b) => b.id === id);

  if (index === -1) {
    return h.response({ status: "fail", message: "Book not found" }).code(404);
  }

  books[index] = { ...books[index], title, author, year, summary };

  return h.response({ status: "success", message: "Book updated" });
};

// ✅ Menghapus buku
const deleteBookHandler = (request, h) => {
  const { id } = request.params;
  const index = books.findIndex((b) => b.id === id);

  if (index === -1) {
    return h.response({ status: "fail", message: "Book not found" }).code(404);
  }

  books.splice(index, 1);
  return h.response({ status: "success", message: "Book deleted" });
};

module.exports = {
  addBookHandler,
  getAllBooksHandler,
  getBookByIdHandler,
  updateBookHandler,
  deleteBookHandler,
};
